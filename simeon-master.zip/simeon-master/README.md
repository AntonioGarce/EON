# SimEON
Simulator for Elastic Optical Networks

For details, please refer to our article, https://link.springer.com/article/10.1007/s11107-017-0697-9
