#ifndef AMPLIFIERS_H
#define AMPLIFIERS_H

#include <Devices/Amplifiers/Amplifier.h>
#include <Devices/Amplifiers/BoosterAmplifier.h>
#include <Devices/Amplifiers/EDFA.h>
#include <Devices/Amplifiers/InLineAmplifier.h>
#include <Devices/Amplifiers/PreAmplifier.h>

#endif // AMPLIFIERS_H

