#ifndef NSGA_II_H
#define NSGA_II_H

#include "NSGA-II/NSGA2.h"
#include "NSGA-II/NSGA2_Generation.h"
#include "NSGA-II/NSGA2_Individual.h"
#include "NSGA-II/NSGA2_Parameter.h"

#endif // NSGA_II_H

