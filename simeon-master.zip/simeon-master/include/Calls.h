#ifndef CALLS_H
#define CALLS_H

#include <Calls/Call.h>
#include <Calls/CallGenerator.h>
#include <Calls/Event.h>

#endif // CALLS_H

