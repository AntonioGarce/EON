#ifndef PSRVARIANTS_H
#define PSRVARIANTS_H

#include "PSRVariants/AdaptativeWeighingRouting.h"
#include "PSRVariants/LocalPowerSeriesRouting.h"
#include "PSRVariants/MatricialPowerSeriesRouting.h"
#include "PSRVariants/TensorialPowerSeriesRouting.h"

#endif // PSRVARIANTS_H
