#ifndef REGENERATORASSIGNMENTALGORITHMS_H
#define REGENERATORASSIGNMENTALGORITHMS_H

#include <RMSA/RegeneratorAssignmentAlgorithms/FirstLongestReach.h>
#include <RMSA/RegeneratorAssignmentAlgorithms/FirstNarrowestSpectrum.h>
#include <RMSA/RegeneratorAssignmentAlgorithms/ShortestCostRegeneratorAssignment.h>

#endif // REGENERATORASSIGNMENTALGORITHMS_H

