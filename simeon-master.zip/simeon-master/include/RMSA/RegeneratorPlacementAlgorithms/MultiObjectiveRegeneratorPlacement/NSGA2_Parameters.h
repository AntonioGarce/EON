#ifndef NSGA2_PARAMETERS_H
#define NSGA2_PARAMETERS_H

#include "NSGA2_Parameter_BlockingProbability.h"
#include "NSGA2_Parameter_CapEx.h"
#include "NSGA2_Parameter_NumberOfRegenerators.h"
#include "NSGA2_Parameter_OpEx.h"

#endif // NSGA2_PARAMETERS_H
