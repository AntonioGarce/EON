#include "include/GeneralPurposeAlgorithms/IntegrationMethods/IntegrationMethod.h"

using namespace NumericMethods;

IntegrationMethod::IntegrationMethod()
{

}
