#include <Devices/Device.h>

using namespace Devices;

Device::Device(DeviceType DevType) : DevType(DevType)
{

}
