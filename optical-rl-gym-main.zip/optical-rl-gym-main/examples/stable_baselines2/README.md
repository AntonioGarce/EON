# Optical RL-Gym

# These examples are deprecated and no longer supported!

In this folder, you will find a few examples of how to use the Optical RL-Gym in combination with Stable Baselines 2 agents.

Before running the examples, make sure to install the Optical RL-Gym and the Stable Baselines 3 in your Python environment.

Note that Stable Baselines 2 works with [TensorFlow 1.14](https://pypi.org/project/tensorflow/1.14.0/), which in turn requires Python 3.7.
